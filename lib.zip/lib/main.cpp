// ClimateControlLib.h
#ifndef ClimateControlLib_h
#define ClimateControlLib_h

#include <GyverOLED.h>
#include <microDS3231.h>
#include <DHT22.h>
#include "GyverEncoder.h"

#define pinDATA 13
#define MOS_PIN 3
#define Lmot 5
#define Ldir 4
#define Rmot 6
#define Rdir 7
#define CLK A3
#define DT A2
#define SW A1
#define rel 12

class ClimateControl {
public:
    // Конструктор
    ClimateControl();

    // Инициализация системы
    void initSystem();

    // Управление реле
    void relay(int n);

    // Основной цикл обработки
    void processLoop();

    // Установка значений температуры и влажности
    void setTemperature(int temp);
    void setHumidity(int hum);

    // Получение текущих значений
    int getCurrentTemperature();
    int getCurrentHumidity();

    // Управление режимами
    void switchMainMode();
    void switchSubMode();

private:
    // Внутренние переменные состояния
    int glav;
    int rsost;
    int value;    // выбранная температура
    int value1;   // выбранная влажность
    int r;
    unsigned long long tm1;

    // Объекты компонентов
    DHT22 dht22;
    GyverOLED<SSD1306_128x64, OLED_NO_BUFFER> oled;
    MicroDS3231 rtc;
    Encoder enc1;

    // Внутренние методы
    void displayMainMenu();
    void displayTempHumiditySettings();
    void displayWorkingStatus();
    void controlHeater(int currentTemp);
    void controlHumidifier(int currentHum);
    void updateDisplay();
};

#endif