// ClimateControlLib.cpp
#include "ClimateControlLib.h"

ClimateControl::ClimateControl() : 
    dht22(pinDATA), 
    enc1(CLK, DT, SW),
    glav(1),
    rsost(-1),
    value(0),
    value1(0),
    r(0),
    tm1(millis())
{
}

void ClimateControl::initSystem() {
    enc1.setType(TYPE2);
    pinMode(Ldir, OUTPUT);
    pinMode(Lmot, OUTPUT);
    pinMode(Rdir, OUTPUT);
    pinMode(Rmot, OUTPUT);
    pinMode(MOS_PIN, OUTPUT);
    oled.init();
    oled.clear();
    
    DateTime now = rtc.getTime();
    rtc.setTime(now);
}

void ClimateControl::relay(int n) {
    digitalWrite(rel, n);
}

void ClimateControl::setTemperature(int temp) {
    value = temp;
}

void ClimateControl::setHumidity(int hum) {
    value1 = hum;
}

int ClimateControl::getCurrentTemperature() {
    return dht22.getTemperature();
}

int ClimateControl::getCurrentHumidity() {
    return dht22.getHumidity();
}

void ClimateControl::switchMainMode() {
    if (glav == 0) {
        glav = 1;
    } else if (glav == 1) {
        glav = 0;
        rsost = 0;
        analogWrite(Rmot, 0);
        analogWrite(Lmot, 0);
        digitalWrite(MOS_PIN, 0);
    }
}

void ClimateControl::switchSubMode() {
    if (rsost == -1) {
        rsost = 0;
    } else if (rsost == 0) {
        rsost = 1;
    } else if (rsost == 1) {
        rsost = 2;
    } else if (rsost == 2) {
        rsost = 3;
    } else if (rsost == 3) {
        rsost = 0;
    }
}

void ClimateControl::displayMainMenu() {
    oled.clear();
    oled.setScale(2.0);
    oled.setCursor(0, 0);
    oled.print("CHOOSE MODE");
}

void ClimateControl::displayTempHumiditySettings() {
    oled.clear();
    oled.setScale(1.5);
    oled.setCursor(0, 0);
    oled.print("time: ");
    oled.print(rtc.getTimeString());
    oled.setCursor(0, 2);
    oled.print("date: ");
    oled.print(rtc.getDateString());
    oled.setCursor(0, 4);
    oled.print("temperature: ");
    oled.println(value);
    oled.setCursor(0, 6);
    oled.print("humidity: ");
    oled.println(value1);
    oled.update();
}

void ClimateControl::displayWorkingStatus() {
    oled.clear();
    oled.setScale(1.5);
    oled.setCursor(0, 0);
    oled.print("time: ");
    oled.print(rtc.getTimeString());
    oled.setCursor(0, 2);
    oled.print("date: ");
    oled.print(rtc.getDateString());
    oled.setCursor(0, 4);
    oled.print("temperature: ");
    oled.println(dht22.getTemperature());
    oled.setCursor(0, 6);
    oled.print("humidity: ");
    oled.println(dht22.getHumidity());
    oled.update();
}

void ClimateControl::controlHeater(int currentTemp) {
    if (currentTemp < value) {
        analogWrite(Lmot, 230);
        digitalWrite(Ldir, 0);
    } else {
        analogWrite(Lmot, 0);
        digitalWrite(Ldir, 0);
    }
}

void ClimateControl::controlHumidifier(int currentHum) {
    if (currentHum < value1) {
        digitalWrite(MOS_PIN, 1);
    } else {
        digitalWrite(MOS_PIN, 0);
    }
}

void ClimateControl::processLoop() {
    enc1.tick();
    int t = dht22.getTemperature();
    int h = dht22.getHumidity();

    if (glav == 0) {
        if (rsost == 0) {
            r++;
        } else if (rsost == 1) {
            if (enc1.isRight()) value++;
            if (enc1.isLeft()) value--;
            if (enc1.isTurn()) {
                displayTempHumiditySettings();
            }
        } else if (rsost == 2) {
            if (enc1.isRight()) value1++;
            if (enc1.isLeft()) value1--;
            if (enc1.isTurn()) {
                displayTempHumiditySettings();
            }
        } else if (rsost == 3) {
            controlHeater(t);
            controlHumidifier(h);
            
            if (millis() > tm1 + 1000) {
                displayWorkingStatus();
                tm1 = millis();
            }
        }
    } else if (glav == 1) {
        displayMainMenu();
        delay(1000);
    }

    if (enc1.isHolded()) {
        switchMainMode();
    }
    
    if (enc1.isPress()) {
        switchSubMode();
    }
}